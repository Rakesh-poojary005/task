from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views

router = DefaultRouter()
router.register(r'approval-groups', views.ApprovalGroupViewSet)
router.register(r'system-users', views.SystemUserViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('system-users-list/', views.SystemUserList.as_view(), name='system-user-list'),
    path('create-order/', views.OrderCreate.as_view(), name='create-order'),
    path('approve-order/<int:pk>/', views.OrderApproval.as_view(), name='approve-order'),


]
