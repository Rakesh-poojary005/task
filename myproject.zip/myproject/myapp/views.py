from rest_framework import viewsets
from .models import SystemUser, ApprovalGroup, Order
from .serializers import SystemUserSerializer, ApprovalGroupSerializer,OrderSerializer
from rest_framework import generics, pagination
from rest_framework import generics, permissions
from rest_framework.response import Response
from rest_framework import status


class ApprovalGroupViewSet(viewsets.ModelViewSet):
    queryset = ApprovalGroup.objects.all()
    serializer_class = ApprovalGroupSerializer

class SystemUserViewSet(viewsets.ModelViewSet):
    queryset = SystemUser.objects.all()
    serializer_class = SystemUserSerializer

class SystemUserList(generics.ListAPIView):
    queryset = SystemUser.objects.order_by('date_joined')  # List in chronological order
    serializer_class = SystemUserSerializer
    pagination_class = pagination.LimitOffsetPagination

class OrderCreate(generics.CreateAPIView):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer


class OrderApproval(generics.UpdateAPIView):
    queryset = Order.objects.all()
    serializer_class = OrderSerializer
    permission_classes = [permissions.IsAuthenticated]  # Ensure only logged-in users can approve orders

    def update(self, request, *args, **kwargs):
        instance = self.get_object()

        user = request.user
        current_stage = instance.current_stage
        if not user.groups.filter(name=f'approval_group_stage{current_stage}').exists():
            return Response({"error": "Permission denied"}, status=status.HTTP_403_FORBIDDEN)

        previous_stage = current_stage - 1
        if previous_stage > 0:
            previous_approved_field = f'stage{previous_stage}_approved_by'
            if not getattr(instance, previous_approved_field):
                return Response({"error": f"Order cannot be approved at stage {current_stage} until stage {previous_stage} is approved."}, status=status.HTTP_400_BAD_REQUEST)

        action = request.data.get('action')
        if action == 'approve':
            setattr(instance, f'stage{current_stage}_approved_by', user)
            instance.current_stage += 1
            if current_stage == 4:
                instance.is_approved = True
        elif action == 'reject':
            instance.is_approved = False

        instance.save()
        return Response(OrderSerializer(instance).data)

