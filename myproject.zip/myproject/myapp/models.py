from django.db import models
from django.contrib.auth.models import AbstractUser
from datetime import datetime

class SystemUser(AbstractUser):
    username = models.CharField(max_length=150, unique=True)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30, blank=True, null=True)
    approval_group = models.ForeignKey('ApprovalGroup', on_delete=models.SET_NULL, blank=True, null=True)

class ApprovalGroup(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Order(models.Model):
    ORDER_STATUS_CHOICES = (
        ('Pending', 'Pending'),
        ('Approved Stage 1', 'Approved Stage 1'),
        ('Approved Stage 2', 'Approved Stage 2'),
        ('Approved Stage 3', 'Approved Stage 3'),
        ('Approved Stage 4', 'Approved Stage 4'),
    )

    order_number = models.CharField(max_length=20, unique=True)
    date = models.DateTimeField(default=datetime.now)
    status = models.CharField(max_length=20, choices=ORDER_STATUS_CHOICES, default='Pending')
    stage1_approval_time = models.DateTimeField(null=True, blank=True)
    stage2_approval_time = models.DateTimeField(null=True, blank=True)
    stage3_approval_time = models.DateTimeField(null=True, blank=True)
    stage4_approval_time = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return self.order_number

